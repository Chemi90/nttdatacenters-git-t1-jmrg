package EjercicioEntornos;

public class Calculadora {

	public double suma(double a, double b) {
		double res = a + b;
		return res;
	}
	public double resta(double a, double b) {
		double res = a - b;
		return res;
	}
}
